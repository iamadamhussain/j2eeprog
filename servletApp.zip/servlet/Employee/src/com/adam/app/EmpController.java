package com.adam.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.SingleThreadModel;
import javax.servlet.annotation.WebServlet;
@WebServlet("/saveemp")
public class EmpController extends GenericServlet implements SingleThreadModel{

	
	@Override
	public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {

	String name=req.getParameter("nm");	
	String address=req.getParameter("add");
	int salary=Integer.parseInt(req.getParameter("sal"));
	
	PrintWriter out=resp.getWriter();
	Connection con;
	int num=0;
	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		con = 
DriverManager.getConnection("jdbc:mysql://localhost:3306/jjs6",
		"root","root");
		System.out.println(con);
		String sql = "insert into emp values(?,?,?)";

		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2,address);
		pstmt.setInt(3, salary);
	num = pstmt.executeUpdate();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
if(num==1)
{
	out.println("Thanks for Registration");
	
}
	else {
		
		out.println("Registration Failed!!!");

	}
	}
}
