package com.adam.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class PrgToEx_Transaction {
	
	
	public static void main(String[] args) {
		
		
		
String url="jdbc:mysql://localhost:3306/btm_j2ee?user=root&password=root";

		String driver="com.mysql.jdbc.Driver";
		Connection connection=null;
		
			try {
				
		
				Class.forName(driver);
				connection=DriverManager.getConnection(url);
				
				Statement st=connection.createStatement();
			ResultSet rs=	st.executeQuery("select * from account");
			System.out.println("-------------View Balance--------------------");

			while(rs.next())
			{
				
			System.out.println(rs.getString("name")+"---------"+rs.getInt("amount"));
			
			
			}//close while loop

			System.out.println("-----TransAction Begins------");
			connection.setAutoCommit(false);
			st.executeUpdate("UPDATE btm_j2ee.account SET amount=amount-500 WHERE id=1");
			st.executeUpdate("UPDATE btm_j2ee.account SET amount=amount+500 WHERE id=6");
			
			Scanner sc=new Scanner(System.in);
			String opt=sc.next();
			
			if(opt.equalsIgnoreCase("yes"))
			{
				
				
				connection.commit();
				System.out.println("---Transaction Completed!!!!------");
			}
			else {
				try {
					connection.rollback();
					connection.commit();
					System.out.println("---rollback-----");

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			
			ResultSet rs1=	st.executeQuery("select * from account");
			System.out.println("-------------View Balance---------------");

			while(rs1.next())
			{
				
			System.out.println(rs1.getString("name")+"---------"+rs1.getInt("amount"));

			
			}//close while loop

			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				
			}
			
		
		
	}

}
