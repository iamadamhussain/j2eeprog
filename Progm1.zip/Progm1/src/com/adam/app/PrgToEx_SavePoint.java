package com.adam.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.Scanner;

public class PrgToEx_SavePoint {
	
	
	public static void main(String[] args) {
		
		
		
String url="jdbc:mysql://localhost:3306/btm_j2ee?user=root&password=root";

		String driver="com.mysql.jdbc.Driver";
		Connection connection=null;
		
			try {
				
		
				Class.forName(driver);
				connection=DriverManager.getConnection(url);
				
				Statement st=connection.createStatement();
		
			System.out.println("-----TransAction Begins------");
			connection.setAutoCommit(false);
			st.executeUpdate("insert into  ka_party values('siddu','handparty')");
			st.executeUpdate("insert into  ka_party values('yeduappa','flowerparty')");
Savepoint sp=		connection.setSavepoint();	//savepoint
st.executeUpdate("insert into  ka_party values('Ragu','jds')");
connection.rollback(sp);
connection.commit();
System.out.println("----rollback--Successfully----");

			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				
			}
			
		
		
	}

}
