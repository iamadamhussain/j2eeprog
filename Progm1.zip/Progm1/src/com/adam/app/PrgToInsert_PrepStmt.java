package com.adam.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

public class PrgToInsert_PrepStmt {
	
	public static void main(String[] args) {
		
		
String url="jdbc:mysql://localhost:3306/btm_j2ee?user=root&password=root";

		String driver="com.mysql.jdbc.Driver";
		Connection connection=null;
		
		try {
			Class.forName(driver);
			
			connection=DriverManager.getConnection(url);
			connection.setAutoCommit(false);	
			
	PreparedStatement pstmt=connection.prepareStatement("insert into employee values(?,?,?)");
pstmt.setInt(1, 777);
pstmt.setString(2, "Dhanu");
pstmt.setString(3, "btm");


Types.v


	
	int count=	pstmt.executeUpdate();
	
	pstmt.setInt(1, 2132);
	pstmt.setString(2, "Dhanu");
	pstmt.setString(3, "btm");





		
		int count=	pstmt.executeUpdate();
		
	
	System.out.println(count);
	connection.commit();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
