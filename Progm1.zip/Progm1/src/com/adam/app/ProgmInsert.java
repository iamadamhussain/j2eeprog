package com.adam.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProgmInsert {
	
	public static void main(String[] args) {
		
	
	String url="jdbc:mysql://localhost:3306/btm_j2ee";
	String user="root";
	String pwd="root";
	String driver="com.mysql.jdbc.Driver";
	Connection connection=null;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter emp id:");
	int id=sc.nextInt();
	System.out.println("Enter emp name:");
	String name=sc.next();
	System.out.println("Enter emp address:");

	String address=sc.next();
	String qry="insert into employee values("+id+",'"+name+"','"+address+"')";

	//String qry1=String.format("insert into employee values(%d,%s,%s)", id,name,address);
	System.out.println();
try {
	
	Class.forName(driver);
	
	 connection=DriverManager.getConnection(url, user, pwd);
	 //by default jdbc is autocommit true,
	 //we can make false by using below line
	 //at last we need maually commit
	connection.setAutoCommit(false);
	
	Statement statement=connection.createStatement();
	
	
	int updatecount=statement.executeUpdate(qry);
	
	System.out.println("data inserted successfully &*&*&"+updatecount);
	connection.commit();

} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
finally {
	if(connection!=null)
		
	{
		
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


		
	}

}
