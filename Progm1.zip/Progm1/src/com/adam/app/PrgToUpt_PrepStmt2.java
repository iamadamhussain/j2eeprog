package com.adam.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PrgToUpt_PrepStmt2 {
	
	public static void main(String[] args) {
		
		
String url="jdbc:mysql://localhost:3306/btm_j2ee?user=root&password=root";

		String driver="com.mysql.jdbc.Driver";
		Connection connection=null;
		
		try {
			Class.forName(driver);
			
			connection=DriverManager.getConnection(url);
			
			
	PreparedStatement pstmt=
connection.prepareStatement("update employee set eaddress=? where eid=?");
pstmt.setString(1, "vijaynagar");
pstmt.setInt(2, 457);



	
	int count=	pstmt.executeUpdate();
	System.out.println("Data Inserted !!!"+count);
	
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
