package com.adam.app;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Clo {
public static void main(String[] args) {
	
	List ll=new ArrayList();
	
	
	ll.add("111");
	ll.add(128.0);
	ll.add("a");
	ll.add("a");
	
	System.out.println(ll);
	
	Iterator it=ll.iterator();
	
	while (it.hasNext()) {
		
		System.out.println(it.next());
		
	}


	
	
}
}
