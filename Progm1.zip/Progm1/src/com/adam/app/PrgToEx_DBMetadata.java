package com.adam.app;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.Scanner;

public class PrgToEx_DBMetadata {
	
	
	public static void main(String[] args) {
		
		
		
String url="jdbc:mysql://localhost:3306/btm_j2ee?user=root&password=root";

		String driver="com.mysql.jdbc.Driver";
		Connection connection=null;
		
			try {
				
		
				Class.forName(driver);
				connection=DriverManager.getConnection(url);
				
		Statement st=connection.createStatement();
	ResultSet rs=	st.executeQuery("select * from Ka_party");
	
	ResultSetMetaData rsd=rs.getMetaData();
	System.out.println(rsd.getColumnCount());
	
		/*		
		DatabaseMetaData dbd=		connection.getMetaData();
			
		System.out.println("Db Name/version"+dbd.getDatabaseProductName());	
		System.out.println("Db Name/version"+dbd.getDatabaseProductVersion());	
System.out.println(dbd.get);
			*/
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				
			}
			
		
		
	}

}
