package com.adam.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ProgToSelect {
public static void main(String[] args) {
	String url="jdbc:mysql://localhost:3306/btm_j2ee";
	String user="root";
	String pwd="root";
	String driver="com.mysql.jdbc.Driver";
	Connection connection=null;
	String sqlqry="select * from employee";

	try {
		Class.forName(driver);
		connection=DriverManager.getConnection(url, user, pwd);
		
		Statement st=connection.createStatement();
		
	ResultSet rs=	st.executeQuery(sqlqry);
	
	while(rs.next())
		
	{
		System.out.println("--Emp Id--"+rs.getInt("id"));
		System.out.println("--Emp Name--"+rs.getString(2));
		System.out.println("--Emp Address--"+rs.getString(3));


		System.out.println("------------------------------");
	
	}
	
	
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
}
}
