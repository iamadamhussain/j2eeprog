package com.adam.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class PrgToStmt_Batch {
	
	
	public static void main(String[] args) {
		
		String url="jdbc:mysql://localhost:3306/btm_j2ee";
		String user="root";
		String pwd="root";
		String driver="com.mysql.jdbc.Driver";
		Connection connection=null;
		
		try {
			Class.forName(driver);
			
			 connection=DriverManager.getConnection(url, user, pwd);
			 
				Statement statement=connection.createStatement();
statement.addBatch("insert into employee values(444,'Ashoka','Indranagar')");
statement.addBatch("delete  from employee  where eid=111");

statement.addBatch("update  employee set eaddress='vijaynagar' where eid=888");
int r[]=statement.executeBatch();
for(int i=0;i<r.length;i++)
{
System.out.println("query executed!!!"+r[i]);
}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
