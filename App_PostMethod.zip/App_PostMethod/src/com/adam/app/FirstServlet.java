package com.adam.app;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FirstServlet  extends HttpServlet{

	
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	
	String nm=req.getParameter("nm");
	
/*	
PrintWriter out=	resp.getWriter();

out.println("Welcome to   Rarra ra nagar "+nm);*/
	
	
System.out.println("inisde first servlet");
RequestDispatcher rd=null;
req.setAttribute("key1", nm);
rd=req.getRequestDispatcher("/secondservlet");//url pattern of next servlet

rd.forward(req, resp);

	
}

}
