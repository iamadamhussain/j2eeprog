package com.adam.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;

import com.sun.org.apache.bcel.internal.generic.SALOAD;
@WebServlet(value="/reademplist44")
public class Read_EmployeeInfo extends GenericServlet {
Connection con=null;


	@Override
	public void init() throws ServletException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jjs6", "root", "root");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Override
		public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
		
	ServletContext context=	getServletContext();
	context.getInitParameter("n1");
	
	
	
		PreparedStatement pstmt=null;
		String name = null,address=null;
		int salary=0;
		try {
pstmt=	con.prepareStatement("select * from emp");
ResultSet  rs=		pstmt.executeQuery();
PrintWriter out=resp.getWriter();
out.println("<html><body>");
out.print(" <table><th>Emp Name</th><th>Emp Address</th><th>Emp Salary</th>");

while(rs.next())
{
	
				name = rs.getString(1);
				address = rs.getString(2);
				salary = rs.getInt(3);
				out.print(" <tr><td>"+name+"</td><td>"+address+"</td><td>"+salary+"</td></tr>");	
}
out.println("</table>");

out.println("</body></html>");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		
		
		
		}
	
	
}
