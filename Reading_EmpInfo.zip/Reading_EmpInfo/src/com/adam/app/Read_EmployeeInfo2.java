package com.adam.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.bcel.internal.generic.SALOAD;
@WebServlet(value="/reademplist")
public class Read_EmployeeInfo2 extends HttpServlet {
Connection con=null;


	@Override
	public void init() throws ServletException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jjs6", "root", "root");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher dispatcher=null;
		PreparedStatement pstmt=null;
		String name = null,address=null;
		ArrayList<Employee> list=new ArrayList<Employee>();

		int salary=0;
		try {
pstmt=	con.prepareStatement("select * from emp");
ResultSet  rs=		pstmt.executeQuery();

while(rs.next())
{
	
				name = rs.getString(1);
				address = rs.getString(2);
				salary = rs.getInt(3);
				//pojo class or javabean class
				Employee employee=new Employee();
				employee.setName(name);
				employee.setAddress(address);
				employee.setSalary(salary);
				
				list.add(employee);

				
	
	req.setAttribute("listofemp", list);
	dispatcher=req.getRequestDispatcher("success.jsp");
				
}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		dispatcher.forward(req, resp);
		
		}
	
	
	
}
